const ctx = document.getElementById('myChart');

if (ctx && typeof Chart !== 'undefined') {
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: window.chartLabels,
            datasets: [
                {
                    label: 'Total',
                    data: window.chartTotals,
                    backgroundColor: '#007bff'
                },
                {
                    label: 'Paid',
                    data: window.chartPaids,
                    backgroundColor: '#28a745'
                },
                {
                    label: 'Pending',
                    data: window.chartPendings,
                    backgroundColor: '#e53935'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
} else if (ctx) {
    console.error('Chart.js failed to load — check that /static/js/chart.umd.min.js is present.');
}
