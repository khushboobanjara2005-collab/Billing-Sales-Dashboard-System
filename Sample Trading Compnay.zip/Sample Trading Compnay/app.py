import os
from flask import Flask, render_template, request, redirect, abort
from flask_wtf.csrf import CSRFProtect
from datetime import datetime

from modules.db import get_db, init_db
from modules.calculations import calculate_bill
from modules.utils import number_to_words

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deploying")

csrf = CSRFProtect(app)

init_db()


@app.context_processor
def inject_today():
    # Used by templates to cap date inputs at today's date (client-side UX only;
    # the real enforcement happens server-side in generate() and save_edit()).
    return {"today": datetime.now().strftime("%Y-%m-%d")}


# ---------------- ERROR HANDLERS ---------------- #

@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", code=404, message="Page not found."), 404

@app.errorhandler(400)
def bad_request(e):
    return render_template("error.html", code=400, message="Bad request."), 400

@app.errorhandler(500)
def server_error(e):
    return render_template("error.html", code=500, message="Something went wrong on our end."), 500


# ---------------- HELPER ---------------- #

PRODUCT_LABELS = {
    "briquettes": "Briquettes",
    "firewood":   "Firewood",
    "-":          "Other",
}


def product_label(value):
    """Human-readable product name. '-' in the DB means 'no specific product', shown as 'Other'."""
    return PRODUCT_LABELS.get(value, value)


app.jinja_env.filters["product_label"] = product_label


def to_iso_date(d):
    """Convert a 'DD-MM-YYYY' string to 'YYYY-MM-DD' for use in <input type=date max=...>."""
    if not d:
        return ""
    try:
        return datetime.strptime(d, "%d-%m-%Y").strftime("%Y-%m-%d")
    except ValueError:
        return ""


def fetch_parties():
    conn = get_db()
    try:
        cur = conn.cursor()
        cur.execute("SELECT name, gstin FROM parties")
        return cur.fetchall()
    finally:
        conn.close()


# ---------------- HOME ---------------- #

@app.route("/")
def index():
    return render_template("form.html", parties=fetch_parties())


# ---------------- CREATE BILL ---------------- #

@app.route("/generate", methods=["POST"])
def generate():

    serial_no  = request.form.get("serial_no", "").strip()
    name       = request.form.get("name", "").strip()
    gstin      = request.form.get("gstin", "").strip()
    product    = request.form.get("product", "").strip()
    slip_no    = request.form.get("slip_no", "").strip()
    apply_gst  = request.form.get("apply_gst") == "on"

    try:
        weight = float(request.form["weight"])
        rate   = float(request.form["rate"])
    except (ValueError, KeyError):
        return render_template("form.html", parties=fetch_parties(),
                               error="Weight and Rate must be valid numbers."), 400

    if not serial_no:
        return render_template("form.html", parties=fetch_parties(),
                               error="Bill Serial No is required."), 400
    if not name:
        return render_template("form.html", parties=fetch_parties(),
                               error="Company Name is required."), 400
    if weight <= 0:
        return render_template("form.html", parties=fetch_parties(),
                               error="Weight must be greater than zero."), 400
    if rate <= 0:
        return render_template("form.html", parties=fetch_parties(),
                               error="Rate must be greater than zero."), 400
    if product not in ("briquettes", "firewood", "-"):
        return render_template("form.html", parties=fetch_parties(),
                               error="Invalid product type selected."), 400

    today = datetime.now().date()

    # Invoice date (defaults to today if left blank)
    date_input = request.form.get("date", "").strip()
    if date_input:
        try:
            date_obj = datetime.strptime(date_input, "%Y-%m-%d").date()
        except ValueError:
            return render_template("form.html", parties=fetch_parties(),
                                   error="Invoice date is not valid."), 400
        if date_obj > today:
            return render_template("form.html", parties=fetch_parties(),
                                   error="Invoice date cannot be in the future."), 400
    else:
        date_obj = today

    date = date_obj.strftime("%d-%m-%Y")

    # Weighbridge date (optional, but if given must be on/before the invoice date)
    weigh_date_input = request.form.get("weigh_date", "").strip()
    if weigh_date_input:
        try:
            weigh_date_obj = datetime.strptime(weigh_date_input, "%Y-%m-%d").date()
        except ValueError:
            return render_template("form.html", parties=fetch_parties(),
                                   error="Weighbridge date is not valid."), 400
        if weigh_date_obj > today:
            return render_template("form.html", parties=fetch_parties(),
                                   error="Weighbridge date cannot be in the future."), 400
        if weigh_date_obj > date_obj:
            return render_template("form.html", parties=fetch_parties(),
                                   error="Weighbridge date cannot be after the invoice date."), 400
        weigh_date = weigh_date_obj.strftime("%d-%m-%Y")
    else:
        weigh_date = ""

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("SELECT id FROM bills WHERE serial_no = ?", (serial_no,))
        if cur.fetchone():
            return render_template(
                "form.html",
                parties=fetch_parties(),
                error=f"Bill No '{serial_no}' already exists. Use a different serial number."
            ), 400

        base, sgst, cgst, total, final, round_off = calculate_bill(
            product, weight, rate, apply_gst=apply_gst
        )
        amount_words = number_to_words(int(final)) + " Rupees Only"

        cur.execute("SELECT id FROM parties WHERE name = ?", (name,))
        party = cur.fetchone()

        if party:
            party_id = party[0]
        else:
            cur.execute(
                "INSERT INTO parties (name, gstin) VALUES (?, ?)",
                (name, gstin)
            )
            party_id = cur.lastrowid

        cur.execute("""
            INSERT INTO bills
            (serial_no, party_id, date, product, weight, rate,
             base, sgst, cgst, total, final, round_off, slip_no, weigh_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            serial_no, party_id, date, product, weight, rate,
            float(base), float(sgst), float(cgst),
            float(total), float(final), float(round_off),
            slip_no, weigh_date
        ))

        conn.commit()

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    return render_template("invoice.html", data={
        "serial_no":    serial_no,
        "date":         date,
        "weigh_date":   weigh_date,
        "name":         name,
        "gstin":        gstin,
        "product":      product,
        "weight":       weight,
        "rate":         rate,
        "base":         base,
        "sgst":         sgst,
        "cgst":         cgst,
        "total":        total,
        "final":        final,
        "round_off":    round_off,
        "amount_words": amount_words,
        "slip_no":      slip_no
    })


# ---------------- VIEW BILL (for reprint) ---------------- #

@app.route("/view/<int:bill_id>")
def view_bill(bill_id):

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("""
            SELECT b.serial_no, b.date, b.product, b.weight, b.rate,
                   b.base, b.sgst, b.cgst, b.total, b.final, b.round_off,
                   p.name, p.gstin, b.slip_no, b.weigh_date
            FROM bills b
            JOIN parties p ON b.party_id = p.id
            WHERE b.id = ?
        """, (bill_id,))

        row = cur.fetchone()
        if not row:
            abort(404)

    finally:
        conn.close()

    final = row[9]
    amount_words = number_to_words(int(final)) + " Rupees Only"

    return render_template("invoice.html", data={
        "serial_no":    row[0],
        "date":         row[1],
        "product":      row[2],
        "weight":       row[3],
        "rate":         row[4],
        "base":         row[5],
        "sgst":         row[6],
        "cgst":         row[7],
        "total":        row[8],
        "final":        row[9],
        "round_off":    row[10],
        "name":         row[11],
        "gstin":        row[12],
        "slip_no":      row[13] or "",
        "weigh_date":   row[14] or "",
        "amount_words": amount_words
    })


# ---------------- DASHBOARD ---------------- #

@app.route("/dashboard")
def dashboard():

    search = request.args.get("search", "")

    conn = get_db()
    try:
        cur = conn.cursor()

        if search:
            cur.execute("""
                SELECT p.id, p.name,
                       COALESCE(SUM(b.final), 0) AS total,
                       COALESCE(SUM(b.paid),  0) AS paid
                FROM parties p
                LEFT JOIN bills b ON b.party_id = p.id
                WHERE p.name LIKE ?
                GROUP BY p.id, p.name
            """, ('%' + search + '%',))
        else:
            cur.execute("""
                SELECT p.id, p.name,
                       COALESCE(SUM(b.final), 0) AS total,
                       COALESCE(SUM(b.paid),  0) AS paid
                FROM parties p
                LEFT JOIN bills b ON b.party_id = p.id
                GROUP BY p.id, p.name
            """)

        rows = cur.fetchall()

        data     = []
        labels   = []
        totals   = []
        paids    = []
        pendings = []

        for row in rows:
            party_id, party_name, total, paid = row
            pending = total - paid

            data.append((party_id, party_name, total, paid, pending))
            labels.append(party_name)
            totals.append(total)
            paids.append(paid)
            pendings.append(pending)

    finally:
        conn.close()

    return render_template(
        "dashboard.html",
        data=data,
        search=search,
        labels=labels,
        totals=totals,
        paids=paids,
        pendings=pendings
    )


# ---------------- LEDGER ---------------- #

@app.route("/ledger/<int:party_id>")
def ledger(party_id):

    search = request.args.get("search", "")
    product_filter = request.args.get("product", "").strip().lower()
    if product_filter not in ("briquettes", "firewood", "-"):
        product_filter = ""

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("SELECT name FROM parties WHERE id=?", (party_id,))
        row = cur.fetchone()
        if not row:
            abort(404)
        name = row[0]

        query = """
            SELECT id, date, serial_no, total, final, paid, product
            FROM bills
            WHERE party_id=?
        """
        params = [party_id]

        if search:
            query += " AND serial_no LIKE ?"
            params.append('%' + search + '%')

        if product_filter:
            query += " AND product = ?"
            params.append(product_filter)

        cur.execute(query, params)
        bills = cur.fetchall()

    finally:
        conn.close()

    return render_template(
        "ledger.html",
        bills=bills,
        name=name,
        party_id=party_id,
        search=search,
        product_filter=product_filter
    )


# ---------------- PAYMENT ---------------- #

@app.route("/pay/<int:bill_id>", methods=["POST"])
def pay(bill_id):

    try:
        amount = float(request.form["amount"])
    except (ValueError, KeyError):
        abort(400)

    if amount <= 0:
        abort(400)

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("SELECT id, party_id, final, paid FROM bills WHERE id=?", (bill_id,))
        bill = cur.fetchone()
        if not bill:
            abort(404)

        party_id    = bill[1]
        final       = bill[2]
        paid_so_far = bill[3]
        remaining   = final - paid_so_far

        if amount > remaining + 0.01:
            abort(400)

        cur.execute(
            "UPDATE bills SET paid = paid + ? WHERE id=?",
            (amount, bill_id)
        )
        conn.commit()

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    return redirect(f"/ledger/{party_id}")


# ---------------- DELETE BILL ---------------- #

@app.route("/delete/<int:bill_id>", methods=["POST"])
def delete_bill(bill_id):

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("SELECT party_id FROM bills WHERE id=?", (bill_id,))
        row = cur.fetchone()
        if not row:
            abort(404)

        party_id = row[0]

        cur.execute("DELETE FROM bills WHERE id=?", (bill_id,))

        cur.execute("SELECT COUNT(*) FROM bills WHERE party_id=?", (party_id,))
        remaining = cur.fetchone()[0]

        if remaining == 0:
            cur.execute("DELETE FROM parties WHERE id=?", (party_id,))
            conn.commit()
            return redirect("/dashboard")

        conn.commit()

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    return redirect(f"/ledger/{party_id}")


# ---------------- DELETE LEDGER ---------------- #

@app.route("/delete-ledger/<int:party_id>", methods=["POST"])
def delete_ledger(party_id):

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("DELETE FROM bills WHERE party_id=?", (party_id,))
        cur.execute("DELETE FROM parties WHERE id=?", (party_id,))
        conn.commit()

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    return redirect("/dashboard")


# ---------------- EDIT BILL (SHOW FORM) ---------------- #

@app.route("/edit/<int:bill_id>")
def edit_bill(bill_id):

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("""
            SELECT b.id, b.serial_no, b.date, b.product, b.weight,
                   b.rate, b.paid, b.party_id,
                   p.name, p.gstin, b.slip_no, b.weigh_date,
                   b.sgst, b.cgst
            FROM bills b
            JOIN parties p ON b.party_id = p.id
            WHERE b.id = ?
        """, (bill_id,))

        row = cur.fetchone()
        if not row:
            abort(404)

    finally:
        conn.close()

    bill = {
        "id":         row[0],
        "serial_no":  row[1],
        "date":       row[2],
        "date_iso":   to_iso_date(row[2]),
        "product":    row[3],
        "weight":     row[4],
        "rate":       row[5],
        "paid":       row[6],
        "party_id":   row[7],
        "name":       row[8],
        "gstin":      row[9],
        "slip_no":    row[10] or "",
        "weigh_date": row[11] or "",
        "apply_gst":  (row[12] or 0) > 0
    }

    return render_template("edit_bill.html", bill=bill)


# ---------------- EDIT BILL (SAVE) ---------------- #

@app.route("/edit/<int:bill_id>", methods=["POST"])
def save_edit(bill_id):

    serial_no  = request.form.get("serial_no", "").strip()
    name       = request.form.get("name", "").strip()
    gstin      = request.form.get("gstin", "").strip()
    product    = request.form.get("product", "").strip()
    slip_no    = request.form.get("slip_no", "").strip()
    apply_gst  = request.form.get("apply_gst") == "on"

    try:
        weight = float(request.form["weight"])
        rate   = float(request.form["rate"])
    except (ValueError, KeyError):
        abort(400)

    if not serial_no or not name or weight <= 0 or rate <= 0:
        abort(400)

    if product not in ("briquettes", "firewood", "-"):
        abort(400)

    today = datetime.now().date()

    # Invoice date (blank = keep existing value)
    date_input = request.form.get("date", "").strip()
    date_obj = None
    if date_input:
        try:
            date_obj = datetime.strptime(date_input, "%Y-%m-%d").date()
        except ValueError:
            abort(400)
        if date_obj > today:
            abort(400)

    # Weighbridge date (blank = keep existing value)
    weigh_date_input = request.form.get("weigh_date", "").strip()
    weigh_date_provided = bool(weigh_date_input)
    weigh_date_obj = None
    if weigh_date_provided:
        try:
            weigh_date_obj = datetime.strptime(weigh_date_input, "%Y-%m-%d").date()
        except ValueError:
            abort(400)
        if weigh_date_obj > today:
            abort(400)

    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute(
            "SELECT id FROM bills WHERE serial_no = ? AND id != ?",
            (serial_no, bill_id)
        )
        if cur.fetchone():
            cur.execute("""
                SELECT b.id, b.serial_no, b.date, b.product, b.weight,
                       b.rate, b.paid, b.party_id, p.name, p.gstin,
                       b.slip_no, b.weigh_date, b.sgst, b.cgst
                FROM bills b JOIN parties p ON b.party_id = p.id
                WHERE b.id = ?
            """, (bill_id,))
            row = cur.fetchone()
            bill = {
                "id": row[0], "serial_no": row[1], "date": row[2],
                "date_iso": to_iso_date(row[2]),
                "product": row[3], "weight": row[4], "rate": row[5],
                "paid": row[6], "party_id": row[7], "name": row[8],
                "gstin": row[9], "slip_no": row[10] or "",
                "weigh_date": row[11] or "",
                "apply_gst": (row[12] or 0) > 0
            }
            return render_template(
                "edit_bill.html", bill=bill,
                error=f"Bill No '{serial_no}' already exists."
            ), 400

        cur.execute("SELECT party_id, date, weigh_date FROM bills WHERE id=?", (bill_id,))
        row = cur.fetchone()
        if not row:
            abort(404)
        current_party_id, existing_date_str, existing_weigh_date_str = row

        cur.execute("SELECT name FROM parties WHERE id=?", (current_party_id,))
        current_name = cur.fetchone()[0]

        if name == current_name:
            cur.execute(
                "UPDATE parties SET gstin = ? WHERE id = ?",
                (gstin, current_party_id)
            )
            new_party_id = current_party_id

        else:
            cur.execute(
                "SELECT COUNT(*) FROM bills WHERE party_id = ? AND id != ?",
                (current_party_id, bill_id)
            )
            other_bills_count = cur.fetchone()[0]

            if other_bills_count == 0:
                cur.execute("SELECT id FROM parties WHERE name = ?", (name,))
                existing = cur.fetchone()

                if existing:
                    new_party_id = existing[0]
                    cur.execute("DELETE FROM parties WHERE id=?", (current_party_id,))
                else:
                    cur.execute(
                        "UPDATE parties SET name = ?, gstin = ? WHERE id = ?",
                        (name, gstin, current_party_id)
                    )
                    new_party_id = current_party_id

            else:
                cur.execute("SELECT id FROM parties WHERE name = ?", (name,))
                existing = cur.fetchone()

                if existing:
                    new_party_id = existing[0]
                else:
                    cur.execute(
                        "INSERT INTO parties (name, gstin) VALUES (?, ?)",
                        (name, gstin)
                    )
                    new_party_id = cur.lastrowid

                cur.execute(
                    "SELECT COUNT(*) FROM bills WHERE party_id = ? AND id != ?",
                    (current_party_id, bill_id)
                )
                if cur.fetchone()[0] == 0:
                    cur.execute("DELETE FROM parties WHERE id=?", (current_party_id,))

        # Resolve final invoice date (existing value if left blank)
        if date_obj is not None:
            date = date_obj.strftime("%d-%m-%Y")
            final_date_obj = date_obj
        else:
            date = existing_date_str
            final_date_obj = datetime.strptime(existing_date_str, "%d-%m-%Y").date()

        # Resolve final weighbridge date (existing value if left blank),
        # and make sure it never lands after the invoice date.
        if weigh_date_provided:
            if weigh_date_obj > final_date_obj:
                abort(400)
            weigh_date = weigh_date_obj.strftime("%d-%m-%Y")
        else:
            weigh_date = existing_weigh_date_str or ""
            if weigh_date:
                existing_weigh_date_obj = datetime.strptime(weigh_date, "%d-%m-%Y").date()
                if existing_weigh_date_obj > final_date_obj:
                    # The invoice date moved earlier than the weighbridge date
                    # that was already on file — don't silently leave an
                    # inconsistent pair of dates in the database.
                    abort(400)

        base, sgst, cgst, total, final, round_off = calculate_bill(
            product, weight, rate, apply_gst=apply_gst
        )

        cur.execute("""
            UPDATE bills
            SET serial_no=?, date=?, product=?, weight=?, rate=?,
                base=?, sgst=?, cgst=?, total=?, final=?, round_off=?,
                party_id=?, slip_no=?, weigh_date=?
            WHERE id=?
        """, (
            serial_no, date, product, weight, rate,
            float(base), float(sgst), float(cgst),
            float(total), float(final), float(round_off),
            new_party_id, slip_no, weigh_date,
            bill_id
        ))

        conn.commit()

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    return redirect(f"/ledger/{new_party_id}")


# ---------------- RUN ---------------- #

if __name__ == "__main__":
    app.run(port=8000, debug=False)
