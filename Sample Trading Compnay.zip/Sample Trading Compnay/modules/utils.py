def number_to_words(n):
    """
    Converts a non-negative integer to its Indian numbering system words.
    Supports up to 99,99,99,999 (99 crore).
    Raises ValueError for negative numbers or values above supported range.
    """

    if not isinstance(n, int):
        n = int(n)

    if n < 0:
        raise ValueError(f"number_to_words() does not support negative numbers: {n}")

    if n > 999999999:
        raise ValueError(f"number_to_words() supports up to 99 crore only. Got: {n}")

    units = [
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven",
        "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen",
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    ]

    tens = [
        "", "", "Twenty", "Thirty", "Forty", "Fifty",
        "Sixty", "Seventy", "Eighty", "Ninety"
    ]

    def _below_hundred(num):
        if num == 0:
            return ""
        elif num < 20:
            return units[num]
        else:
            t = tens[num // 10]
            u = units[num % 10]
            return t + (" " + u if u else "")

    def _below_thousand(num):
        if num == 0:
            return ""
        elif num < 100:
            return _below_hundred(num)
        else:
            hundreds  = units[num // 100] + " Hundred"
            remainder = _below_hundred(num % 100)
            return hundreds + (" " + remainder if remainder else "")

    if n == 0:
        return "Zero"

    parts = []

    # Crore (1,00,00,000)
    if n >= 10000000:
        crore = n // 10000000
        parts.append(_below_hundred(crore) + " Crore")
        n %= 10000000

    # Lakh (1,00,000)
    if n >= 100000:
        lakh = n // 100000
        parts.append(_below_hundred(lakh) + " Lakh")
        n %= 100000

    # Thousand (1,000)
    if n >= 1000:
        thousand = n // 1000
        parts.append(_below_hundred(thousand) + " Thousand")
        n %= 1000

    # Below thousand
    if n > 0:
        parts.append(_below_thousand(n))

    return " ".join(parts)
