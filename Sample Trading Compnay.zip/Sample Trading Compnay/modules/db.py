import os
import sqlite3

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "database.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    return conn


def init_db():
    conn = get_db()
    try:
        cur = conn.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS parties (
                id     INTEGER PRIMARY KEY AUTOINCREMENT,
                name   TEXT UNIQUE NOT NULL,
                gstin  TEXT
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS bills (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                serial_no  TEXT UNIQUE NOT NULL,
                party_id   INTEGER NOT NULL,
                date       TEXT NOT NULL,
                product    TEXT NOT NULL,
                weight     REAL NOT NULL,
                rate       REAL NOT NULL,
                base       REAL NOT NULL,
                sgst       REAL NOT NULL,
                cgst       REAL NOT NULL,
                total      REAL NOT NULL,
                final      REAL NOT NULL,
                round_off  REAL NOT NULL,
                paid       REAL NOT NULL DEFAULT 0,
                slip_no    TEXT DEFAULT "",
                weigh_date TEXT DEFAULT "",
                FOREIGN KEY (party_id) REFERENCES parties(id)
            )
        """)

        # Migrate existing databases
        try:
            cur.execute('ALTER TABLE bills ADD COLUMN slip_no TEXT DEFAULT ""')
            conn.commit()
        except Exception:
            pass

        try:
            cur.execute('ALTER TABLE bills ADD COLUMN weigh_date TEXT DEFAULT ""')
            conn.commit()
        except Exception:
            pass

        conn.commit()

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
