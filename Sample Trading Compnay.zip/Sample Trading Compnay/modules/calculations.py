from decimal import Decimal, ROUND_HALF_UP


def calculate_bill(product, weight, rate, apply_gst=False):
    """
    Calculates bill amounts using Decimal to avoid floating point errors.

    - briquettes: always 5% GST (2.5% CGST + 2.5% SGST)
    - firewood:   optional GST via apply_gst
    - "-":        optional GST via apply_gst

    Returns:
        base, sgst, cgst, total, final, round_off
        All returned as float (safe for Jinja templates and SQLite storage).
    """

    weight = Decimal(str(weight))
    rate   = Decimal(str(rate))
    zero   = Decimal("0")

    base = weight * rate

    if product == "briquettes" or ((product in ("firewood", "-")) and apply_gst):
        sgst = (Decimal("0.025") * base).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        cgst = (Decimal("0.025") * base).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    else:
        sgst = zero
        cgst = zero

    total     = base + sgst + cgst
    final     = total.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    round_off = (final - total).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    return (
        float(base),
        float(sgst),
        float(cgst),
        float(total),
        float(final),
        float(round_off)
    )
