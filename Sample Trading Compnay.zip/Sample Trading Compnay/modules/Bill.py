# Program to calculate total cost for briquettes/firewood

# Select product type
print("Select Product Type:")
print("1. Briquettes (GST Applicable)")
print("2. Firewood (No GST)")

product_choice = int(input("Enter your choice (1 or 2): "))

# Input net weight
net_weight = float(input("\nEnter net weight (in kg): "))

# Rate selection
print("\nSelect rate option:")
print("1. Enter custom rate")
print("2. Choose from predefined rates")

choice = int(input("Enter your choice (1 or 2): "))

if choice == 1:
    rate = float(input("Enter rate per kg: "))
elif choice == 2:
    print("\nAvailable Rates:")
    print("1. 10.00")
    print("2. 10.50")
    print("3. 11.00")
    print("4. 11.50")
    
    rate_choice = int(input("Select rate option (1-4): "))
    
    if rate_choice == 1:
        rate = 10.00
    elif rate_choice == 2:
        rate = 10.50
    elif rate_choice == 3:
        rate = 11.00
    elif rate_choice == 4:
        rate = 11.50
    else:
        print("Invalid choice! Default rate applied: 10.00")
        rate = 10.00
else:
    print("Invalid choice! Default rate applied: 10.00")
    rate = 10.00

# Base amount
base_amount = net_weight * rate

# Check product type
if product_choice == 1:
    # Briquettes → Apply GST
    sgst = 0.025 * base_amount
    cgst = 0.025 * base_amount
    total_amount = base_amount + sgst + cgst

    final_amount = round(total_amount)

    print("\n--- BILL DETAILS (BRIQUETTES) ---")
    print("Base Amount:", base_amount)
    print("SGST (2.50%):", sgst)
    print("CGST (2.50%):", cgst)
    print("Total (Before Rounding):", total_amount)
    print("Final Payable Amount:", final_amount)

elif product_choice == 2:
    # Firewood → No GST
    total_amount = base_amount
    final_amount = round(total_amount)

    print("\n--- BILL DETAILS (FIREWOOD) ---")
    print("Total Amount (No GST):", total_amount)
    print("Final Payable Amount:", final_amount)

else:
    print("Invalid product choice!")
